window.config = {
  title: "Conteúdo Proibido 🔞",
  headline: "Conteúdo quente liberado por tempo limitado! 🔥",
  description: "Essa gostosa separou o pack completo só pros mais ousados... Você tá dentro?",
  buttonText: "Quero ver tudo agora",
  redirectLink: "https://t.me/vipsbruninha_bot",
  backgroundImage: "assets/imagem.jpg"
}
